# Handoff: Labmate — Login & Boot Splash

## Overview
This package covers the **authentication entry flow** for Labmate, a local-first desktop client for an autonomous agent (the `Brain → Nervous System → Hands` stack: a local llama.cpp model, an MCP bridge, and a skill registry). The flow is three screens:

**Login → Boot splash → Chat**

- **Login** — email/password sign-in (mock).
- **Boot splash** — a handshake screen shown after sign-in while the backend brings subsystems online (model, MCP servers, skills, prior conversations, workspace). It hands off to the chat once everything is ready.
- **Chat** — the main "mission control" interface (already specified in detail in `FRONTEND_SPEC.md`; included here as a reference prototype).

This bundle focuses on the **Login** and **Boot splash**. The chat UI and the full real-time/data/auth contract live in `FRONTEND_SPEC.md` — read it alongside this README.

## About the Design Files
The `.dc.html` files in this bundle are **design references** — interactive HTML prototypes showing the intended look, motion, and behavior. They are **not** production code to copy directly. The task is to **recreate these designs in the target codebase's environment** (the Labmate desktop app — e.g. React in Tauri/Electron) using its established patterns, component library, and styling approach. If no frontend environment exists yet, choose the most appropriate framework and implement there.

`support.js` is the prototype runtime that makes the `.dc.html` files open standalone in a browser — **ignore it for implementation**; it is not part of the design.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, motion, and interactions are all specified below with exact values. Recreate pixel-perfectly using the codebase's existing libraries. The one exception is the optional logistic-regression background animation on the splash, which is an ambient flourish — match its spirit, exact point positions are not load-bearing.

---

## Design Tokens

### Color
| Token | Hex | Use |
|---|---|---|
| bg / surface | `#0f1115` | app background |
| bg deep | `#0b0d11`, `#07080b` | body behind, montage base |
| panel | `#13161c` | cards, boot panel |
| panel alt | `#101319` | nested figure card (v2) |
| input | `#15181e` | field backgrounds |
| border | `#20242c` | card borders |
| border input | `#2a2f39` | input borders |
| row divider | `#181c22` | boot row separators |
| accent · blue (Brain) | `#6aa6ff` | primary accent, negative class |
| accent · purple (Nervous System) | `#a78bfa` | login default accent, sigmoid curve |
| accent · green (Hands / ready) | `#56c08d`, bright `#7bc699` | success, positive class |
| warning · amber | `#d8a657` | degraded states |
| error · red | `#e0676a` | error dot/text |
| text strong | `#f0f2f5` | headings |
| text body | `#e6e8ec` | inputs, body |
| text muted | `#7e8693` | subtitles |
| text faint | `#5e6671`, `#6b727d` | mono labels, sublabels |
| text dim | `#4f5662`, `#454d59` | placeholders, chrome label |
| traffic dots | `#37404c` | window chrome |

Brand mark gradient: `linear-gradient(140deg, #6aa6ff, #a78bfa)`, glyph color `#0a0c10`.
Progress bar fill: `linear-gradient(90deg, #6aa6ff, #a78bfa)`.

### Typography
- **UI:** `IBM Plex Sans` (300–700). Headings 20–22px/600, body 13–14px/400, subtitles 13–13.5px.
- **Mono:** `IBM Plex Mono` (400–600) — field labels (10px, `letter-spacing:.12em`, uppercase), the spec readout (14px), status lines, code, the boot sublabels/status words.
- **Serif:** `IBM Plex Serif` — only used in the v2 alternate (typeset-paper motif). Not used in v1.
- Headings use `letter-spacing:-.01em`. Taglines use `text-wrap:balance`.

### Radius / Shadow / Spacing
- Radius: cards `16px`, inputs `10px`, brand mark `12–13px`, status pills/dots circular, subsystem LED dots `3px`.
- Card shadow: `0 24px 60px -28px rgba(0,0,0,.7)` (login/boot panel); deeper `0 30px 70px -30px rgba(0,0,0,.8)`.
- Brand mark glow: `0 8px 30px -8px rgba(106,166,255,.5)`.
- Engineering graph-paper background (both screens): two layered grids via `background-image` linear-gradients —
  - minor: `#ffffff05` lines at `24px` (or `22px`) tiles
  - major: `#ffffff08` lines at `120px` (or `110px`) tiles
- Ambient glow: `radial-gradient(700px 480px at 22% 16%, rgba(106,166,255,.06), transparent 70%)` + `radial-gradient(620px 460px at 82% 88%, rgba(167,139,250,.05), transparent 72%)`.

---

## Screens / Views

### 1. Login — `Labmate Login.dc.html`
**Purpose:** Sign the user into their local mission control.

**Layout:** Full-viewport (`100vh`) column on `#0f1115`. Back-to-front: ambient glow + graph-paper (both `position:absolute; inset:0; pointer-events:none`), then a 38px window-chrome bar (three `11px` `#37404c` dots, left), then a flex-centered content area holding the sign-in column.

**Top-left cluster** (`position:absolute; top:54px; left:36px`):
- Spec readout — `IBM Plex Mono` 14px `#7e8693`, `white-space:nowrap`: `gemma-3-4b · 4.3B · ctx 16,384 · 12 skills · build 0.1.0`. `margin-bottom:14px`.
- Tagline — 17px/600 `#cfd4da`, `line-height:1.4`, `max-width:340px`, `text-wrap:balance`: "Run the experiment, read the diff, draft the paper — in one place."

**Centered card** (width `380px`):
- Header (centered): brand mark `46×46`, radius 13, gradient, mono "L", 22px — then "Welcome to Labmate" (21px/600 `#f0f2f5`) — then "Sign in to your agent mission control" (13.5px `#7e8693`). `margin-bottom:30px`.
- Card: `#13161c`, border `1px #20242c`, radius 16, padding `24px 24px 22px`, shadow `0 24px 60px -28px rgba(0,0,0,.7)`. Contains:
  - **Error row** (conditional): bg `#1f1417`, border `1px #4a2a2e`, radius 9, `6px` red `#e0676a` dot + message `#e09aa0` 12.5px. Copy: "Enter your email and password to continue."
  - **Email**: mono uppercase label `#5e6671`; input `#15181e`, border `1px #2a2f39`, radius 10, padding `11px 13px`, 14px text. Placeholder `you@lab.dev` (`#4f5662`).
  - **Password**: label row with "Forgot?" link (`#7e8693`→`#a6adb8` hover) on the right; input as above with right-aligned show/hide toggle (mono 10.5px, "show"/"hide", hover bg `#1b1f26`); type swaps `password`/`text`.
  - **Remember**: 17px checkbox (filled = accent bg + `#0a0c10` ✓; empty = `#15181e` border `#2f3742`) + "Keep me signed in on this machine" (13px `#939ba7`).
  - **Submit**: full-width, accent background, `#0a0c10` text, 14px/600, radius 10, padding `12px 14px`; hover `filter:brightness(1.07)`.
  - **Footer link**: "No workspace yet? **Create one**" (accent).
- **Status footer** (below card, centered): mono 10.5px `#5e6671` — green `#56c08d` pulsing dot + "local instance reachable · llama.cpp :8000 · v0.1.0".

**Focus state (inputs):** `border-color:<accent>; box-shadow:0 0 0 3px <accent>26`.

**Tweakable props:** `accent` (enum `blue`|`purple`|`green`, default **purple**) drives the button/checkbox/focus-ring/links; `showError` (boolean) previews the error state.

> An alternate layout, **`Labmate Login v2.dc.html`** (two-column "lab bench" with a typeset paper + training-run figure), is included for reference only. v1 is canonical.

### 2. Boot splash — `Labmate Boot.dc.html`
**Purpose:** Cover the post-login handshake — show real subsystems coming online, then mount the chat. **Not a timer in production:** drive each row from backend readiness events (`boot.plan` / `boot.update` / `boot.ready` / `boot.error`) per `FRONTEND_SPEC.md §3.5`. The prototype simulates this with timers.

**Layout:** Same bg + graph paper. Centered column width `452px`:
- Brand mark `46×46` with a gentle **breathe** animation (`scale 1→1.04`, shadow shift, 2.4s ease-in-out infinite) — then "Starting Labmate" (20px/600) — then "Bringing your agent online" (13px `#7e8693`).
- **Boot panel** (`#13161c`, border `#20242c`, radius 16): one row per subsystem. Each row: a `9×9` radius-3 LED dot in the subsystem color (with glow `box-shadow:0 0 0 4px <c>1f, 0 0 12px <c>66` when lit) · label (14px/500 `#dfe3e8`) + mono sublabel (11px `#6b727d`) · right-side status. Rows are `opacity:.4` when pending, `1` when lit, `transition:opacity .45s`. Bottom border `#181c22` except last.
  - Status per state: **pending** → mono "queued" `#4f5662`; **active** → spinner (`13px`, 2px ring `<c>33` + `<c>` top, `spin .6s linear infinite`); **done** → mono done-word `#5e6671` + green ✓ in a `#56c08d22` circle.
  - Subsystems (label · sublabel · color · done-word):
    1. Brain · `gemma-3-4b · llama.cpp :8000` · `#6aa6ff` · online
    2. Nervous System · `MCP bridge · 4 servers` · `#a78bfa` · connected
    3. Hands · `skills · 12 loaded` · `#56c08d` · ready
    4. Memory · `restoring 8 conversations` · `#6aa6ff` · synced
    5. Workspace · `context · files · settings` · `#a78bfa` · ready
- **Progress** (`margin-top:20px`): 4px track `#191d24`; fill = `ready_count / total`, blue→purple gradient, `transition:width .5s`. Below: status text (`Starting <subsystem>…` / "All systems online") with a pulsing/solid dot, and right-aligned `NN%`.

**Prototype timing:** first row activates immediately; each subsequent row at `420 + i·stepMs` (default `stepMs = 640`); at the end the screen fades (`opacity 0`, `.55s`) and navigates to the chat. Replace with event-driven readiness in production.

**Optional logistic-regression background** (`showPlot` prop, default **off**): an ambient full-bleed SVG behind the panel. A scatter of two classes — **blue negative** (`rgba(106,166,255,.46)`) pooled lower-left, **green positive** (`rgba(123,198,153,.52)`) upper-right, jittered into two bands — with a **purple sigmoid** decision curve (`#a78bfa`, 2.6px, soft 9px glow) and a faint dashed decision boundary at the midpoint. On load the curve eases (easeOutCubic) from a shallow near-flat guess (`k≈0.9`) to the fitted steepness (`k≈12`), **completing ~220ms before the last subsystem reports ready**, then brightens to settle. Drawn imperatively into the SVG and animated with `requestAnimationFrame` so it survives re-renders. Purely decorative — reproduce the effect, not the exact points.

**Tweakable props:** `showPlot` (boolean, default false), `freeze` (boolean — hold without navigating, for inspection), `stepMs` (int 200–1500, default 640).

### 3. Chat — `Labmate.dc.html`
Reference prototype of the destination. Fully documented in `FRONTEND_SPEC.md` (layout, modes, real-time protocol, debug mode, data model). Login routes here via the splash.

---

## Interactions & Behavior
- **Login submit:** validates non-empty email + password (else show error row). On success: disable inputs, swap button to a spinner + "Authenticating…", then route to the boot splash. In production, call `POST /auth/login` and gate the session WebSocket (`FRONTEND_SPEC.md §3.5`).
- **Enter** submits the login form. **Show/hide** toggles password visibility. **Forgot / Create one** are placeholder links (no destination yet).
- **Boot:** rows advance pending→active→done; progress bar tracks `ready_count/total`; on all-ready, fade out and mount chat. Production: react to `boot.*` events; on `boot.error` for a required subsystem, halt with Retry / Back-to-login.
- **Motion:** brand breathe (2.4s), spinners (0.6s linear), row opacity (0.45s), progress width (0.5s), screen fade (0.55s), optional curve fit (eased over the load duration). Figure cards in v2 use a 7s `drift`.

## State Management
- **Login:** `email`, `password`, `showPw`, `remember`, `submitting`, `error`. In production add the `AuthSession`/token lifecycle from `§3.5` (keychain / httpOnly cookie; never localStorage or URL).
- **Boot:** `idx` (subsystems ready so far), `fading`. In production replace the timer-driven `idx` with subsystem states from `boot.update`, and carry the `SessionBootstrap` payload from `boot.ready` into the chat for a warm start.

## Assets
No external image/icon assets — everything is CSS/SVG. Fonts load from Google Fonts (`IBM Plex Sans`, `IBM Plex Mono`, and `IBM Plex Serif` for the v2 alternate only); swap to the codebase's font pipeline. The "L" brand mark is a gradient tile with a mono glyph — replace with the real Labmate logo if one exists.

## Files
| File | What it is |
|---|---|
| `Labmate Login.dc.html` | **Canonical** login (v1) — implement this |
| `Labmate Boot.dc.html` | Boot splash with subsystem handshake + optional logistic background |
| `Labmate Login v2.dc.html` | Alternate login (two-column lab bench) — reference only |
| `Labmate.dc.html` | Chat interface — reference prototype |
| `FRONTEND_SPEC.md` | Full build spec: chat UI, data model, real-time protocol, auth (§3.5), boot handshake |
| `support.js` | Prototype runtime — **not part of the design; ignore** |
